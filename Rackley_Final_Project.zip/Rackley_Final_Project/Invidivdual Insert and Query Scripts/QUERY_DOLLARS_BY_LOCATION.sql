SELECT p.state
 ,CONCAT('$',FORMAT(SUM(t.total_amount),2)) as total_awarded_amount
FROM (SELECT p.id
  ,i.state AS state
FROM projects p
JOIN institutions i
ON p.institution_id = i.id
WHERE i.country = 'USA'
UNION 
SELECT p.id
  ,l.state as state
FROM projects p
JOIN unaffiliated_project_locations l
ON p.id = l.project_id
WHERE l.country = 'USA') p 
JOIN (SELECT project_id
  ,SUM(amount) as total_amount
FROM (SELECT project_id
  ,supplement_amount as amount
FROM supplements
UNION
SELECT project_id
  ,original_amount as amount
FROM awards) all_ammounts
GROUP BY project_id) t
ON p.id = t.project_id
GROUP BY p.state 
ORDER BY p.state ASC