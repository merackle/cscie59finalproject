SELECT DISTINCT p.id
  ,p.project_title
  ,a.year_awarded
FROM (SELECT p.id
  ,p.project_title
FROM projects p
JOIN institutions i
ON p.institution_id = i.id
WHERE i.institution_name LIKE '%Harvard University%' AND p.status = 2 
UNION
SELECT p.id
  ,p.project_title
FROM projects p
JOIN project_participants pp
ON p.id = pp.project_id
JOIN institutions i
ON pp.institution_id = i.id  
WHERE i.institution_name LIKE '%Harvard University%' AND p.status = 2) p 
JOIN awards a
ON p.id = a.project_id
ORDER BY a.year_awarded, p.id
