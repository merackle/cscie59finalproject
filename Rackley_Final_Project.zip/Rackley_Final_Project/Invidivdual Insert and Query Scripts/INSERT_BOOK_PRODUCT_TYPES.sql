INSERT INTO book_product_types (product_type) VALUES ('Scholarly Edition');
INSERT INTO book_product_types (product_type) VALUES ('Edited Volume');
INSERT INTO book_product_types (product_type) VALUES ('Single author monograph');
INSERT INTO book_product_types (product_type) VALUES ('Multi-author monograph');
INSERT INTO book_product_types (product_type) VALUES ('Translation');
INSERT INTO book_product_types (product_type) VALUES ('Other');
