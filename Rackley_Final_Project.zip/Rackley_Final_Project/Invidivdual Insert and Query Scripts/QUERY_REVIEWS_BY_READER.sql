SELECT d.division_name
  ,CONCAT(r.last_name,', ',r.first_name) as reader_name
  ,r.id AS reader_id
  ,IF(r.end_date IS NULL, 'Yes', 'No') AS current_employee
  ,CASE
	WHEN r.end_date IS NOT NULL THEN FORMAT(DATEDIFF(r.end_date,r.start_date)/365,1) 
    ELSE FORMAT(DATEDIFF(now(),r.start_date)/365,1)
    END AS years_worked
  ,pr.review_count 
  ,pr.avg_rating
FROM readers r
LEFT JOIN (SELECT reader_id
  ,COUNT(id) AS review_count
  ,FORMAT(SUM(review_rating)/COUNT(id),1) AS avg_rating
FROM project_reviews
WHERE review_date IS NOT NULL
GROUP BY reader_id) pr
ON pr.reader_id = r.id
JOIN divisions d
ON r.division_id = d.id
ORDER BY d.division_name, r.last_name
