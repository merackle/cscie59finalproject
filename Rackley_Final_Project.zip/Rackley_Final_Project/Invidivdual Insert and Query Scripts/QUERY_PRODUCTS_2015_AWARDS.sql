SELECT p.id
 ,p.project_title
 ,"Book" AS product_type
 ,b.title AS product_title
 ,b.publication_year AS product_date
FROM book_products b
JOIN projects p
ON b.project_id = p.id
JOIN awards a
ON p.id = a.project_id
WHERE a.year_awarded = '2015'
UNION
SELECT p.id
 ,p.project_title
 ,"Conference Presentation" AS product_type
 ,cp.title AS product_title
 ,cp.presentation_date AS product_date
FROM conference_presentation_products cp
JOIN projects p
ON cp.project_id = p.id
JOIN awards a
ON p.id = a.project_id
WHERE a.year_awarded = '2015'
ORDER BY id, product_date ASC