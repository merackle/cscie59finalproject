SELECT grant_size
  ,COUNT(DISTINCT(s.project_id)) AS project_count
  ,SUM(p.product_count) AS product_count
  ,SUM(p.product_count)/COUNT(DISTINCT(s.project_id)) AS average_products
FROM
(SELECT a.project_id
,CASE 
  WHEN a.original_amount > 300001 THEN 'Large Grant - more than $300,000'
  WHEN a.original_amount BETWEEN 50001 AND 300000 THEN 'Medium Grant - $50,001 to $300,000'
  WHEN a.original_amount <= 50000 THEN 'Small Grant - $50,000 or less'
  ELSE 'N/A' 
 END AS grant_size 
FROM awards a) s
LEFT JOIN (SELECT bp.project_id
  ,COUNT(*) AS product_count
FROM book_products bp
GROUP BY bp.project_id
UNION
SELECT cp.project_id
  ,COUNT(*) AS product_count
FROM conference_presentation_products cp
GROUP BY cp.project_id) p
ON s.project_id = p.project_id
GROUP BY grant_size


