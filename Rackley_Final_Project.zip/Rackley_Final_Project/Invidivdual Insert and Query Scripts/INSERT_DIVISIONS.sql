INSERT INTO divisions (division_name) VALUES ('Challenge Programs');
INSERT INTO divisions (division_name) VALUES ('Public Programs');
INSERT INTO divisions (division_name) VALUES ('Education Programs');
INSERT INTO divisions (division_name) VALUES ('Research Programs');
INSERT INTO divisions (division_name) VALUES ('Preservation and Access');
INSERT INTO divisions (division_name) VALUES ('Federal/State Partnership');
INSERT INTO divisions (division_name) VALUES ('Digital Humanities');
INSERT INTO divisions (division_name) VALUES ('Agency-wide Projects');
