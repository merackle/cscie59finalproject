SELECT DISTINCT discipline_name
FROM project_disciplines pd
JOIN projects p
ON pd.project_id = p.id
JOIN disciplines d
ON pd.discipline_id	= d.id
JOIN programs pr
ON p.program_id = pr.id
JOIN divisions di
ON pr.division_id = di.id
WHERE di.id = 6 AND pd.discipline_category = 1
ORDER BY discipline_name ASC
