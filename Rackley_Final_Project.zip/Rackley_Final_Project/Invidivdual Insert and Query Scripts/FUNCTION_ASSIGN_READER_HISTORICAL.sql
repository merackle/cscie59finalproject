DELIMITER $$
	CREATE FUNCTION assignreader (iProjectID VARCHAR(255))	
            RETURNS INT NOT DETERMINISTIC
			READS SQL DATA
	BEGIN
		DECLARE oReaderId INT;
		IF iProjectID IS NOT NULL 
			THEN SET oReaderId = (SELECT r.id
                    FROM (SELECT r.id
                      ,r.start_date
                      ,IF(r.end_date IS NULL, now(), r.end_date) AS end_date
					FROM readers r 
					JOIN divisions d
					ON r.division_id = d.id
					WHERE d.id = (SELECT d.id FROM projects pr
					JOIN programs p
					ON pr.program_id = p.id
					JOIN divisions d
					ON p.division_id = d.id 
					WHERE pr.id = iProjectId)) r
                    WHERE (SELECT a.year_awarded FROM awards a
					JOIN projects pr
					ON a.project_id = pr.id
					WHERE pr.id = iProjectID) BETWEEN YEAR(r.start_date) AND YEAR(r.end_date)
					ORDER BY rand() LIMIT 1);	
		ELSE
			SET oReaderId = -1;
		END IF;

		RETURN oReaderId;

	END $$

DELIMITER ;
